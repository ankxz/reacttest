
  # WhatsApp Cloud API Platform

  This is a code bundle for WhatsApp Cloud API Platform. The original project is available at https://www.figma.com/design/Ykyu8h2pFlS8CMLgjqWU1O/WhatsApp-Cloud-API-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  